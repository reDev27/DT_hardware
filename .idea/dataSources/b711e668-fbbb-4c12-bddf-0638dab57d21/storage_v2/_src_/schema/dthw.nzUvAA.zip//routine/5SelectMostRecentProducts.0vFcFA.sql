create
    definer = root@localhost procedure `5SelectMostRecentProducts`()
begin

    select * from prodotto
    order by DATAINSERIMENTO desc
    limit 0,10;

end;

