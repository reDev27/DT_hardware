create
    definer = root@localhost procedure InsertCategoria(IN nomeIn varchar(50), IN quantitaIn int)
begin

    insert into CATEGORIA values
    (nomeIn,quantitaIn);

end;

