create
    definer = root@localhost procedure InsertCompone(IN nprodottiIn int, IN codiceABarreIn char(12))
begin
    declare idIn int;

    set idIn = (select max(ID) from ordine);

    insert into COMPONE values
    (codiceABarreIn, idIn, nprodottiIn);

end;

