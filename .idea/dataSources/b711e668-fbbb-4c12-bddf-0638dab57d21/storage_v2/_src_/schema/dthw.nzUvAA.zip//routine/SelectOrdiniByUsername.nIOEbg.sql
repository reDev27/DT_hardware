create
    definer = root@localhost procedure SelectOrdiniByUsername(IN usernameIn varchar(30))
begin

    select id, fattura, TOTALE, DATAACQUISTO
    from ordine
    where USERNAME=usernameIn;

end;

