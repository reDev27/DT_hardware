create
    definer = root@localhost procedure selectCategoria()
begin

    select NOME, QUANTITA from categoria;

end;

