create
    definer = root@localhost procedure selectProdotto(IN codiceABarreIn char(12), OUT codiceABarreOut char(12),
                                                      OUT prezzoOut double, OUT descrizioneOut varchar(1000),
                                                      OUT specificheOut varchar(1000), OUT immagineOut longblob,
                                                      OUT quantitaOut int, OUT marcaOut varchar(50),
                                                      OUT modelloOut varchar(50), OUT datainserimentoOut timestamp)
begin

    set codiceABarreOut = (select CODICEBARRE from prodotto where CODICEBARRE=codiceABarreIn);
    set prezzoOut = (select PREZZO from prodotto where CODICEBARRE=codiceABarreIn);
    set descrizioneOut = (select DESCRIZIONE from prodotto where CODICEBARRE=codiceABarreIn);
    set specificheOut = (select SPECIFICHE from prodotto where CODICEBARRE=codiceABarreIn);
    set immagineOut = (select IMMAGINE from prodotto where CODICEBARRE=codiceABarreIn);
    set quantitaOut = (select QUANTITA from prodotto where CODICEBARRE=codiceABarreIn);
    set marcaOut = (select MARCA from prodotto where CODICEBARRE=codiceABarreIn);
    set modelloOut = (select MODELLO from prodotto where CODICEBARRE=codiceABarreIn);
    set datainserimentoOut = (select DATAINSERIMENTO from prodotto where CODICEBARRE=codiceABarreIn);
end;

