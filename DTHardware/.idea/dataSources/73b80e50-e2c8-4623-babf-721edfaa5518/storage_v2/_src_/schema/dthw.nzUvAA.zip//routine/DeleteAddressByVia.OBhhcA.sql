create
    definer = root@localhost procedure DeleteAddressByVia(IN viaIn varchar(50), IN nCivicoIn int, IN usernameIn varchar(30))
begin

    delete from risiede where VIA=viaIn and NCIVICO=nCivicoIn and USERNAME=usernameIn;
    delete from indirizzo where VIA=viaIn and NCIVICO=nCivicoIn;

end;

