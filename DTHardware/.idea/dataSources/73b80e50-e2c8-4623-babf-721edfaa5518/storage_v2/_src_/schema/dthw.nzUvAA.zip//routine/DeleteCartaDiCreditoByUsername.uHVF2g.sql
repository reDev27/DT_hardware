create
    definer = root@localhost procedure DeleteCartaDiCreditoByUsername(IN usernameIn varchar(30))
begin

    delete from cartadicredito
    where username=usernameIn;

end;

