create
    definer = root@localhost procedure DeleteClienteByUsername(IN usernameIn varchar(30))
begin

    delete from cliente
    where username=usernameIn;

end;

