create
    definer = root@localhost procedure DeleteComponeByCodiceABarre(IN codiceabarreIn char(12))
begin

    delete from compone
    where CODICEaBARRE=codiceabarreIn;

end;

