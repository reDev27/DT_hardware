create
    definer = root@localhost procedure DeleteComponeById(IN idIn varchar(30))
begin

    delete from compone
    where IDORDINE=idIn;

end;

