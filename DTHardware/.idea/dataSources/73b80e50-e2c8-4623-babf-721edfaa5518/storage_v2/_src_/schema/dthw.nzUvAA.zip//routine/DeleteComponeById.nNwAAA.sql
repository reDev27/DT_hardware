create
    definer = root@localhost procedure DeleteComponeById(IN idIn int)
begin

    delete from compone
    where IDORDINE=idIn;

end;

