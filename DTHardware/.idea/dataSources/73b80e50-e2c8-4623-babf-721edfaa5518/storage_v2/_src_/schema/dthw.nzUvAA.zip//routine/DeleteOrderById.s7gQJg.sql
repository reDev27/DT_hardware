create
    definer = root@localhost procedure DeleteOrderById(IN idIn int)
begin

    delete from ordine
    where ID=idIn;

end;

