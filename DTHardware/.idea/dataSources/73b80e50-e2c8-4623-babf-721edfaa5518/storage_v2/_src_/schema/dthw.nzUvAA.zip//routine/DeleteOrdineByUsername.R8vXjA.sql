create
    definer = root@localhost procedure DeleteOrdineByUsername(IN usernameIn varchar(30))
begin

    delete from ordine
    where username=usernameIn;

end;

