create
    definer = root@localhost procedure DeleteProduct(IN codiceabarreIn char(12))
begin

    delete from prodotto
    where CODICEBARRE=codiceabarreIn;

end;

