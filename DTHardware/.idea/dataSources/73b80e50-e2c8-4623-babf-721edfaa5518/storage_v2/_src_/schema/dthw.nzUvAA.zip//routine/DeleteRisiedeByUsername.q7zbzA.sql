create
    definer = root@localhost procedure DeleteRisiedeByUsername(IN usernameIn varchar(30))
begin

    delete from risiede
    where username=usernameIn;

end;

