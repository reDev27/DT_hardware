create
    definer = root@localhost procedure InsertCompone(IN nprodottiIn int, IN idIn int, IN codiceABarreIn char(12))
begin

    insert into COMPONE values
    (nprodottiIn, idIn, codiceABarreIn);

end;

