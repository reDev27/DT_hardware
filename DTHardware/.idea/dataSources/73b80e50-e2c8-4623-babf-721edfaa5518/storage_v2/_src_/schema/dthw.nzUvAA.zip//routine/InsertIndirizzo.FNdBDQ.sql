create
    definer = root@localhost procedure InsertIndirizzo(IN viaIn varchar(50), IN ncivicoIn int, IN cittaIn varchar(20),
                                                       IN capIn int, IN flagIn tinyint(1))
begin

    insert into INDIRIZZO values
    (viaIn,ncivicoIn,cittaIn,capIn,flagIn);

end;

