create
    definer = root@localhost procedure InsertOrdine(IN fatturaIn varchar(1000), IN totaleIn double,
                                                    IN dataacquistoIn timestamp, IN usernameIn varchar(50))
begin
start transaction;

    insert into ORDINE (fattura, totale, dataacquisto, username) values
    (fatturaIn,totaleIn,dataacquistoIn,usernameIn);

commit;
end;

