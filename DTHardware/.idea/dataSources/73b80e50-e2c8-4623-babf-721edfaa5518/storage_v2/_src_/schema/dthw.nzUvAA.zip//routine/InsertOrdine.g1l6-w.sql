create
    definer = root@localhost procedure InsertOrdine(IN idIn int, IN scontoIn int, IN totaleIn double,
                                                    IN dataacquistoIn timestamp, IN usernameIn varchar(50))
begin

    insert into ORDINE values
    (idIn,scontoIn,totaleIn,dataacquistoIn,usernameIn);

end;

