create
    definer = root@localhost procedure InsertProdotto(IN codiceabarreIn int, IN prezzoIn double,
                                                      IN descrizioneIn varchar(1000), IN specificheIn varchar(1000),
                                                      IN immagineIn longblob, IN quantitaIn int, IN marcaIn varchar(50),
                                                      IN modelloIn varchar(50), IN nomeIn varchar(50),
                                                      IN datainserimentoIn timestamp)
begin

    insert into PRODOTTO values
    (codiceabarreIn,prezzoIn,descrizioneIn,specificheIn, immagineIn, quantitaIn,marcaIn,modelloIn,nomeIn,datainserimentoIn);

end;

