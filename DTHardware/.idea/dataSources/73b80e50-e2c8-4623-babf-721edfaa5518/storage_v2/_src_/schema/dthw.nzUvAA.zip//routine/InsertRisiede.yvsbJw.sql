create
    definer = root@localhost procedure InsertRisiede(IN usernameIn varchar(30), IN viaIn varchar(50), IN nCivicoIn int)
begin

    insert into risiede (USERNAME, VIA, NCIVICO) values
    (usernameIn, viaIn, nCivicoIn);

end;

