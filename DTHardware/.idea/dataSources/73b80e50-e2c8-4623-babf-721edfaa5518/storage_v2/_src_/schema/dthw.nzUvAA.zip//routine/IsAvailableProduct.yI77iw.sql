create
    definer = root@localhost procedure IsAvailableProduct(IN codiceABarreIn char(12), IN quantitaIn int)
begin

    select CODICEBARRE from prodotto where codiceABarreIn=CODICEBARRE and QUANTITA<quantitaIn;

end;

