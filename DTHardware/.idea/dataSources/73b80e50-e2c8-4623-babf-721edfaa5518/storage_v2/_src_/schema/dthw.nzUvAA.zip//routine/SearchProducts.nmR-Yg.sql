create
    definer = root@localhost procedure SearchProducts(IN toSearchIn varchar(50))
begin



    select CODICEBARRE, MARCA, MODELLO from prodotto where MARCA like concat('%', toSearchIn, '%') or MARCA like concat(toSearchIn, '%') or MARCA like concat('%', toSearchIn)
                                                        or MODELLO like concat('%', toSearchIn, '%') or MODELLO like concat(toSearchIn, '%') or MODELLO like concat('%', toSearchIn)
                                                        or concat(MARCA, ' ',MODELLO) like concat('%', toSearchIn, '%') or concat(MARCA, ' ',MODELLO) like concat(toSearchIn, '%') or concat(MARCA, ' ', MODELLO) like concat('%', toSearchIn)
                                                        or concat(MODELLO, ' ',MARCA) like concat('%', toSearchIn, '%') or concat(MODELLO, ' ',MARCA) like concat(toSearchIn, '%') or concat(MODELLO, ' ', MARCA) like concat('%', toSearchIn);

end;

