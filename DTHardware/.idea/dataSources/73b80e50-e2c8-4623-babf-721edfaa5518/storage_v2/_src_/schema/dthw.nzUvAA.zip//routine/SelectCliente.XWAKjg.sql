create
    definer = root@localhost procedure SelectCliente()
begin

    select USERNAME,EMAIL,PASSW,NOME,COGNOME,NTELEFONO from cliente;

end;

