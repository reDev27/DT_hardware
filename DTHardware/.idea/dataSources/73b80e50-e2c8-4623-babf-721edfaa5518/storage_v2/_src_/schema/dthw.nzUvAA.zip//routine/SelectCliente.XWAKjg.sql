create
    definer = root@localhost procedure SelectCliente()
begin

    select USERNAME,EMAIL,NOME,COGNOME,NTELEFONO from cliente;

end;

