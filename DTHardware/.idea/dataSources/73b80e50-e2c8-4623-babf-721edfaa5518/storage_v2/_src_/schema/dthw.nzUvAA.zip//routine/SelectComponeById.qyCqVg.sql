create
    definer = root@localhost procedure SelectComponeById(IN idIn int)
begin

    select CODICEABARRE, IDORDINE, NPRODOTTI
    from compone
    where IDORDINE=idIn;

end;

