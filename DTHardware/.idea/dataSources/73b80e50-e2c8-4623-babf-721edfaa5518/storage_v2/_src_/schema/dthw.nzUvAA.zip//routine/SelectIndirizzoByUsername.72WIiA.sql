create
    definer = root@localhost procedure SelectIndirizzoByUsername(IN usernameIn varchar(30))
begin

    select indirizzo.via, indirizzo.NCIVICO, CITTA, CAP, FLAG
    from indirizzo, risiede
    where risiede.USERNAME=usernameIn and indirizzo.VIA=risiede.VIA and indirizzo.NCIVICO=risiede.NCIVICO;

end;

