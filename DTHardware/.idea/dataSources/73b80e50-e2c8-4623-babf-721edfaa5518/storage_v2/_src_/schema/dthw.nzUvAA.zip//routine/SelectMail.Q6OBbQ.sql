create
    definer = root@localhost procedure SelectMail(IN mailIn varchar(30))
begin

    select EMAIL from cliente where email=mailIn;

end;

