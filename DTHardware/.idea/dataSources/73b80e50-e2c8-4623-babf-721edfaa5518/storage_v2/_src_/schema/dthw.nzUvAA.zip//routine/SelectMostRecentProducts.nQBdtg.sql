create
    definer = root@localhost procedure SelectMostRecentProducts()
begin

    select * from prodotto
    order by DATAINSERIMENTO desc
    limit 0,10;

end;

