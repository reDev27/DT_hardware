create
    definer = root@localhost procedure SelectOrderByMaxId(IN usernameIn varchar(30))
begin

    declare maxId int;

    set maxId=(select max(ID) from ordine where USERNAME=usernameIn);

    select maxId;

end;

