create
    definer = root@localhost procedure SelectOrders()
begin

    select id, FATTURA, totale, DATAACQUISTO, USERNAME
    from ordine;

end;

