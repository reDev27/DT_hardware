create
    definer = root@localhost procedure SelectOrdiniByUsername(IN usernameIn varchar(30))
begin

    select id, FATTURA, TOTALE, DATAACQUISTO
    from ordine
    where USERNAME=usernameIn;

end;

