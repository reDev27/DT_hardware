create
    definer = root@localhost procedure SelectProducts()
begin



    select CODICEBARRE, PREZZO, DESCRIZIONE, SPECIFICHE, IMMAGINE,
    QUANTITA, MARCA, MODELLO, NOME, DATAINSERIMENTO
    from prodotto;

end;

