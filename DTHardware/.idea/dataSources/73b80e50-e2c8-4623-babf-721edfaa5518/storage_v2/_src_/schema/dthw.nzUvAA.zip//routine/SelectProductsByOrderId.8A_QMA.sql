create
    definer = root@localhost procedure SelectProductsByOrderId(IN idIn int)
begin

    select CODICEBARRE, PREZZO, IMMAGINE, QUANTITA, MARCA, MODELLO
    from prodotto, compone
    where IDORDINE=idIn and CODICEBARRE=CODICEABARRE;

end;

