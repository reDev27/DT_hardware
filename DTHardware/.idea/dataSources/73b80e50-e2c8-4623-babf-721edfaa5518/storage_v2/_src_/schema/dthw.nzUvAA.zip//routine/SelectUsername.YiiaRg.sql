create
    definer = root@localhost procedure SelectUsername(IN usernameIn varchar(30))
begin

    select USERNAME from cliente where USERNAME=usernameIn;

end;

