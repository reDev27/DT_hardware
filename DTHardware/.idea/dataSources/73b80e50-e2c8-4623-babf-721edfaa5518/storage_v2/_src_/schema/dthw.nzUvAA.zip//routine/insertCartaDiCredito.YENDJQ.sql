create
    definer = root@localhost procedure insertCartaDiCredito(IN ncartaIn char(12), IN scadenzaIn timestamp, IN cvvIn int,
                                                            IN usernameIn varchar(30))
begin
    insert into cartadicredito values
    (ncartaIn, scadenzaIn, cvvIn,usernameIn);

end;

