create
    definer = root@localhost procedure selectProdottoByCodiceABarre(IN codiceABarreIn char(12))
begin

     select CODICEBARRE, PREZZO, DESCRIZIONE, SPECIFICHE, IMMAGINE,
            QUANTITA, MARCA, MODELLO, DATAINSERIMENTO from prodotto where CODICEBARRE=codiceABarreIn;

end;

