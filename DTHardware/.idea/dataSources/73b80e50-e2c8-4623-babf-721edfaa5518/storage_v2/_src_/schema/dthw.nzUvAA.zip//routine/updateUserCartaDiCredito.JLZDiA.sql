create
    definer = root@localhost procedure updateUserCartaDiCredito(IN usernameIn varchar(30), IN ncartaIn char(12))
begin
    update cliente set ncarta=ncartaIn where USERNAME=usernameIn;
end;

