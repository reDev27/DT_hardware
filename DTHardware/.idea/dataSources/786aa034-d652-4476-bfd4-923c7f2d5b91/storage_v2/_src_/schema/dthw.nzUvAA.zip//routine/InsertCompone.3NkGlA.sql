create
    definer = root@localhost procedure InsertCompone(IN nprodottiIn int)
begin

    insert into COMPONE values
    (nprodottiIn);

end;

