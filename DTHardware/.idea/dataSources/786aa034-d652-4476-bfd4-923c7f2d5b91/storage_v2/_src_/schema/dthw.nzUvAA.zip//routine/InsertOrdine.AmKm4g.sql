create
    definer = root@localhost procedure InsertOrdine(IN idIn int, IN scontoIn int, IN totaleIn double)
begin

    insert into ORDINE values
    (idIn,scontoIn,totaleIn);

end;

