create
    definer = root@localhost procedure SelectCartadicreditoByUsername(IN usernameIn varchar(30))
begin

    select (NCARTA,SCADENZA,CVV,USERNAME) from cartadicredito
    where cartadicredito.USERNAME=usernameIn;

end;

