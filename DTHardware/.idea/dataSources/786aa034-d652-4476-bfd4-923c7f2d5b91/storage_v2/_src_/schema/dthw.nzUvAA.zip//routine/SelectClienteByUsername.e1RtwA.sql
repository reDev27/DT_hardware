create
    definer = root@localhost procedure SelectClienteByUsername(IN usernameIn varchar(30))
begin

    select (USERNAME,EMAIL,PASSW,NOME,COGNOME,NTELEFONO) from CLIENTE
    where cliente.USERNAME=usernameIn;

end;

