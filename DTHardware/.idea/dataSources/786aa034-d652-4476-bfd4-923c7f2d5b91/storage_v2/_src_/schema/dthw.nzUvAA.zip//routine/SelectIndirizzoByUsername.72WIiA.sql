create
    definer = root@localhost procedure SelectIndirizzoByUsername(IN usernameIn varchar(30))
begin

    select (VIA,NCIVICO,CITTA,CAP,FLAG,USERNAME) from indirizzo
    where indirizzo.USERNAME=usernameIn;

end;

