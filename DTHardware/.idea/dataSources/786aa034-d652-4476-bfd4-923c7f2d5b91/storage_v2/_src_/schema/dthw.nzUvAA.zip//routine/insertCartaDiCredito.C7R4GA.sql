create
    definer = root@localhost procedure insertCartaDiCredito(IN ncartaIn char(12), IN scadenzaIn timestamp, IN cvvIn int)
begin
    insert into cartadicredito values
    (ncartaIn, scadenzaIn, cvvIn);

end;

