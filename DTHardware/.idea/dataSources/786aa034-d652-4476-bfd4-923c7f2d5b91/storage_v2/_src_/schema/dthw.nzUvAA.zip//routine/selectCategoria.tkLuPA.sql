create
    definer = root@localhost procedure selectCategoria(OUT nomeOut varchar(50), OUT quantitaOut int)
begin

    select NOME, QUANTITA from categoria;

end;

