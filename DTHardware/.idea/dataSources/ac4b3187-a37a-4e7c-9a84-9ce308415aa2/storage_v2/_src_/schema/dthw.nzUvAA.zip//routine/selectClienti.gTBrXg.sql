create
    definer = root@localhost procedure selectClienti()
begin
        select * from cliente;
    end;

